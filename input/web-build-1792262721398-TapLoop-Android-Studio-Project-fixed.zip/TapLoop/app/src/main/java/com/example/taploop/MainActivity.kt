package com.example.taploop

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var intervalInput: EditText
    private lateinit var xInput: EditText
    private lateinit var yInput: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(20))
            setBackgroundColor(Color.rgb(245, 247, 250))
        }
        val scroll = ScrollView(this)
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "TapLoop"
            textSize = 30f
            setTextColor(Color.rgb(23, 38, 58))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Минимальный автокликер для Android"
            textSize = 16f
            setTextColor(Color.rgb(80, 91, 105))
            setPadding(0, dp(4), 0, dp(20))
        })

        status = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.rgb(35, 85, 55))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.rgb(226, 241, 231))
        }
        root.addView(status, marginParams(bottom = 16))

        root.addView(label("Интервал между нажатиями, мс"))
        intervalInput = numberField("500")
        root.addView(intervalInput, marginParams(bottom = 12))

        root.addView(label("Координата X (пиксели; 0 = центр)"))
        xInput = numberField("0")
        root.addView(xInput, marginParams(bottom = 12))

        root.addView(label("Координата Y (пиксели; 0 = центр)"))
        yInput = numberField("0")
        root.addView(yInput, marginParams(bottom = 18))

        root.addView(makeButton("Разрешить службу автокликера") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, marginParams(bottom = 10))

        root.addView(makeButton("Разрешить плавающее окно") {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                showMessage("Разрешение уже выдано.")
            }
        }, marginParams(bottom = 18))

        root.addView(makeButton("▶  СТАРТ") {
            startClicking()
        }, marginParams(bottom = 10))
        root.addView(makeButton("■  СТОП") {
            AutoClickAccessibilityService.activeService?.stopClicking()
            status.text = "Автокликер остановлен."
        }, marginParams(bottom = 18))

        root.addView(TextView(this).apply {
            text = "Как пользоваться\n1. Выдай разрешение службе автокликера.\n2. Разреши плавающее окно.\n3. Укажи интервал и координаты, затем нажми СТАРТ.\n4. Для аварийной остановки нажми красную кнопку СТОП поверх приложений.\n\nX и Y задаются в физических пикселях. Ноль по любой оси означает середину экрана по этой оси. Минимальный интервал: 100 мс."
            textSize = 14f
            setTextColor(Color.rgb(71, 82, 96))
            setPadding(0, dp(8), 0, dp(18))
        })

        setContentView(scroll)
        updateStatus()
    }

    private fun startClicking() {
        if (!isAccessibilityEnabled()) {
            showMessage("Сначала включи TapLoop в настройках специальных возможностей.")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            showMessage("Нужно разрешение на плавающее окно, чтобы на экране была кнопка аварийной остановки.")
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        val service = AutoClickAccessibilityService.activeService
        if (service == null) {
            showMessage("Служба подключается. Вернись в приложение и нажми СТАРТ ещё раз.")
            return
        }

        val interval = intervalInput.text.toString().toLongOrNull()?.coerceIn(100L, 60_000L) ?: 500L
        val x = xInput.text.toString().toIntOrNull()?.coerceAtLeast(0) ?: 0
        val y = yInput.text.toString().toIntOrNull()?.coerceAtLeast(0) ?: 0
        intervalInput.setText(interval.toString())
        xInput.setText(x.toString())
        yInput.setText(y.toString())
        val started = service.startClicking(interval, x, y)
        status.text = if (started) "Автокликер работает. Используй плавающую кнопку СТОП." else "Не удалось создать кнопку СТОП. Проверь разрешение поверх окон."
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getInt(contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 0) == 1
        if (!enabled) return false
        val setting = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val component = ComponentName(this, AutoClickAccessibilityService::class.java).flattenToString()
        return setting.split(':').any { it.equals(component, ignoreCase = true) }
    }

    private fun updateStatus() {
        if (!::status.isInitialized) return
        val accessibility = isAccessibilityEnabled()
        val overlay = Settings.canDrawOverlays(this)
        status.text = "Служба: ${if (accessibility) "включена" else "не включена"} · Плавающее окно: ${if (overlay) "разрешено" else "не разрешено"}"
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(Color.rgb(42, 54, 70))
        setPadding(0, 0, 0, dp(6))
    }

    private fun numberField(value: String) = EditText(this).apply {
        setSingleLine(true)
        inputType = InputType.TYPE_CLASS_NUMBER
        setText(value)
        textSize = 17f
        setPadding(dp(12), dp(9), dp(12), dp(9))
        setBackgroundColor(Color.WHITE)
    }

    private fun makeButton(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = 14f
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun marginParams(bottom: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(bottom)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun showMessage(message: String) {
        AlertDialog.Builder(this).setMessage(message).setPositiveButton("ОК", null).show()
    }
}
