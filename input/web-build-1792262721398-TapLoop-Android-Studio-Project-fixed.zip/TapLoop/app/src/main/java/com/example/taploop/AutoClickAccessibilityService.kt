package com.example.taploop

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.view.accessibility.AccessibilityEvent

class AutoClickAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile
        var activeService: AutoClickAccessibilityService? = null
            private set
    }

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var intervalMs = 500L
    private var requestedX = 0
    private var requestedY = 0
    private var stopView: View? = null
    private var overlayManager: WindowManager? = null

    private val clickLoop = object : Runnable {
        override fun run() {
            if (!running) return
            val metrics = resources.displayMetrics
            @Suppress("DEPRECATION")
            val display = (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay
            @Suppress("DEPRECATION")
            val realMetrics = android.util.DisplayMetrics().also { display.getRealMetrics(it) }
            val x = if (requestedX <= 0) realMetrics.widthPixels / 2f else requestedX.toFloat()
            val y = if (requestedY <= 0) realMetrics.heightPixels / 2f else requestedY.toFloat()
            val boundedX = x.coerceIn(1f, (realMetrics.widthPixels - 1).coerceAtLeast(1).toFloat())
            val boundedY = y.coerceIn(1f, (realMetrics.heightPixels - 1).coerceAtLeast(1).toFloat())
            val path = Path().apply { moveTo(boundedX, boundedY) }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 45))
                .build()
            dispatchGesture(gesture, null, null)
            handler.postDelayed(this, intervalMs)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        activeService = this
    }

    fun startClicking(interval: Long, x: Int, y: Int): Boolean {
        if (!Settings.canDrawOverlays(this)) return false
        intervalMs = interval.coerceIn(100L, 60_000L)
        requestedX = x.coerceAtLeast(0)
        requestedY = y.coerceAtLeast(0)
        if (!showStopButton()) return false
        running = true
        handler.removeCallbacks(clickLoop)
        handler.post(clickLoop)
        return true
    }

    fun stopClicking() {
        running = false
        handler.removeCallbacks(clickLoop)
        removeStopButton()
    }

    private fun showStopButton(): Boolean {
        if (stopView != null) return true
        if (!Settings.canDrawOverlays(this)) return false
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        overlayManager = wm
        val button = Button(this).apply {
            text = "СТОП"
            textSize = 13f
            isAllCaps = true
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(198, 40, 40))
            setOnClickListener { stopClicking() }
            contentDescription = "Остановить автокликер"
        }
        val density = resources.displayMetrics.density
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = (10 * density).toInt()
            y = (90 * density).toInt()
        }
        return try {
            wm.addView(button, params)
            stopView = button
            true
        } catch (_: Exception) {
            stopView = null
            false
        }
    }

    private fun removeStopButton() {
        val view = stopView ?: return
        try {
            overlayManager?.removeView(view)
        } catch (_: Exception) {
            // The system may already have removed the overlay.
        }
        stopView = null
        overlayManager = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() {
        stopClicking()
    }

    override fun onDestroy() {
        stopClicking()
        if (activeService === this) activeService = null
        super.onDestroy()
    }
}
