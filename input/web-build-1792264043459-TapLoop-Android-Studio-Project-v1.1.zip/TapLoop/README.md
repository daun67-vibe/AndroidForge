# TapLoop 1.1

A minimal Android auto-clicker with a floating control panel, tap interval configuration, and three point-selection modes.

## Features
- Dark theme by default, with a saved light/dark theme switch.
- Custom launcher icon.
- Persistent floating start/stop button while the accessibility service is enabled and overlay permission is granted.
- Center of screen, manual X/Y coordinates, or tap-to-pick coordinates.
- In tap-to-pick mode, the target icon (⌖) appears on the floating panel. Press it and tap the desired screen location; the coordinates are saved for future clicks.
- The picker temporarily pauses an active click loop, then resumes it after the new point is saved.
- Interval range: 100 to 60,000 ms.

## Build
- Android Gradle Plugin configured in the repository's existing build files.
- `compileSdk = 35`, `minSdk = 26`, `targetSdk = 35`.
- Java and Kotlin target JVM 17.
- Build a debug APK with `gradle assembleDebug`.

## First launch
1. Enable TapLoop in Android Accessibility settings.
2. Grant TapLoop permission to display over other apps.
3. Pick the mode, interval, and point in the app.
4. Use the floating green play button to start and red square button to stop.

Accessibility gestures are used to issue taps. Coordinate-pick mode places a brief transparent overlay over the screen; the tap used to choose the point is captured by the overlay and is not passed through to the underlying app.
