package com.example.taploop

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var intervalInput: EditText
    private lateinit var xInput: EditText
    private lateinit var yInput: EditText
    private lateinit var status: TextView
    private lateinit var statusDetail: TextView
    private lateinit var pointDetails: TextView
    private lateinit var coordinateFields: LinearLayout
    private lateinit var pickPanel: LinearLayout
    private lateinit var centerPanel: TextView
    private lateinit var modeCenterButton: TextView
    private lateinit var modeManualButton: TextView
    private lateinit var modePickButton: TextView
    private lateinit var launchButton: TextView

    private var darkTheme = true
    private var selectedMode = TapLoopConfig.MODE_CENTER

    private val prefs by lazy { getSharedPreferences(TapLoopConfig.PREFS, MODE_PRIVATE) }

    private data class Palette(
        val background: Int,
        val surface: Int,
        val surfaceAlt: Int,
        val text: Int,
        val secondary: Int,
        val accent: Int,
        val accentText: Int,
        val border: Int,
        val field: Int,
        val muted: Int
    )

    private val palette: Palette
        get() = if (darkTheme) Palette(
            Color.rgb(11, 16, 32), Color.rgb(18, 27, 45), Color.rgb(25, 37, 59),
            Color.rgb(241, 245, 249), Color.rgb(159, 173, 194), Color.rgb(45, 212, 191),
            Color.rgb(7, 25, 34), Color.rgb(43, 58, 82), Color.rgb(10, 17, 32), Color.rgb(104, 122, 148)
        ) else Palette(
            Color.rgb(245, 247, 252), Color.WHITE, Color.rgb(234, 241, 248),
            Color.rgb(24, 36, 56), Color.rgb(94, 109, 132), Color.rgb(13, 148, 136),
            Color.WHITE, Color.rgb(222, 230, 241), Color.rgb(247, 249, 253), Color.rgb(130, 145, 165)
        )

    override fun onCreate(savedInstanceState: Bundle?) {
        darkTheme = getSharedPreferences(TapLoopConfig.PREFS, MODE_PRIVATE).getBoolean(TapLoopConfig.DARK_THEME, true)
        setTheme(if (darkTheme) com.example.taploop.R.style.AppThemeDark else com.example.taploop.R.style.AppTheme)
        super.onCreate(savedInstanceState)
        selectedMode = prefs.getString(TapLoopConfig.MODE, TapLoopConfig.MODE_CENTER) ?: TapLoopConfig.MODE_CENTER
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        AutoClickAccessibilityService.activeService?.ensureFloatingControls()
        updateStatus()
        updatePointDetails()
    }

    private fun buildUi() {
        val colors = palette
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(28))
            setBackgroundColor(colors.background)
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setPadding(0, 0, 0, dp(8))
            addView(root)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brandColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brandColumn.addView(text("TapLoop", 30f, colors.text, true))
        brandColumn.addView(text("SMART TAP CONTROL", 10f, colors.accent, true).apply {
            letterSpacing = 0.16f
            setPadding(0, dp(1), 0, 0)
        })
        header.addView(brandColumn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(actionChip(if (darkTheme) "☼  Светлая" else "☾  Тёмная", outlined = true) {
            saveFormToPreferences()
            darkTheme = !darkTheme
            prefs.edit().putBoolean(TapLoopConfig.DARK_THEME, darkTheme).apply()
            recreate()
        })
        root.addView(header, marginParams(bottom = 18))

        val hero = card().apply {
            setBackground(rounded(colors.surfaceAlt, 24, colors.surfaceAlt))
        }
        hero.addView(text("Автокликер без лишнего", 21f, colors.text, true))
        hero.addView(text(
            "Задай темп, выбери точку и запускай касания поверх любого приложения.",
            14f, colors.secondary, false
        ).apply { setPadding(0, dp(7), 0, dp(13)) })
        val heroFoot = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        heroFoot.addView(dot(colors.accent))
        heroFoot.addView(text("Кнопка управления остаётся на экране", 12f, colors.secondary, false).apply {
            setPadding(dp(7), 0, 0, 0)
        })
        hero.addView(heroFoot)
        root.addView(hero, marginParams(bottom = 14))

        val statusCard = card()
        statusCard.addView(text("СОСТОЯНИЕ", 11f, colors.secondary, true).apply { letterSpacing = 0.12f })
        status = text("Проверяем разрешения…", 16f, colors.text, true).apply {
            setPadding(0, dp(8), 0, dp(3))
        }
        statusDetail = text("Плавающая кнопка появится после включения службы и разрешения окон.", 13f, colors.secondary, false)
        statusCard.addView(status)
        statusCard.addView(statusDetail)
        root.addView(statusCard, marginParams(bottom = 14))

        val tempoCard = card()
        tempoCard.addView(sectionHeading("01", "Темп нажатий", "Интервал между касаниями"))
        intervalInput = numberField(prefs.getLong(TapLoopConfig.INTERVAL, 500L).toString(), "Например, 500")
        val intervalRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        intervalRow.addView(intervalInput, LinearLayout.LayoutParams(0, dp(52), 1f))
        intervalRow.addView(text("мс", 15f, colors.secondary, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), 0, dp(4), 0)
        })
        tempoCard.addView(intervalRow, marginParams(bottom = 8))
        tempoCard.addView(text("От 100 до 60 000 мс. Например, 500 мс = два нажатия в секунду.", 12f, colors.secondary, false))
        root.addView(tempoCard, marginParams(bottom = 14))

        val pointCard = card()
        pointCard.addView(sectionHeading("02", "Точка нажатия", "Выбери способ указать место"))
        val modeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        modeCenterButton = modeChip("Центр", TapLoopConfig.MODE_CENTER)
        modeManualButton = modeChip("X / Y", TapLoopConfig.MODE_MANUAL)
        modePickButton = modeChip("Касанием", TapLoopConfig.MODE_PICK)
        modeRow.addView(modeCenterButton, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(6) })
        modeRow.addView(modeManualButton, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(6) })
        modeRow.addView(modePickButton, LinearLayout.LayoutParams(0, dp(46), 1f))
        pointCard.addView(modeRow, marginParams(bottom = 12))

        centerPanel = text("Автокликер будет нажимать в центре экрана.", 13f, colors.secondary, false)
        pointCard.addView(centerPanel, marginParams(bottom = 10))

        coordinateFields = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val savedX = prefs.getInt(TapLoopConfig.X, 0)
        val savedY = prefs.getInt(TapLoopConfig.Y, 0)
        xInput = numberField(savedX.toString(), "X в пикселях")
        yInput = numberField(savedY.toString(), "Y в пикселях")
        coordinateFields.addView(xInput, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(8) })
        coordinateFields.addView(yInput, LinearLayout.LayoutParams(0, dp(52), 1f))
        pointCard.addView(coordinateFields, marginParams(bottom = 10))

        pickPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        pickPanel.addView(text(
            "Нажми значок ⌖ на плавающей панели, затем коснись нужного места. Координаты сохранятся автоматически.",
            13f, colors.secondary, false
        ).apply { setPadding(0, 0, 0, dp(9)) })
        pointDetails = text("Точка ещё не выбрана", 12f, colors.accent, true)
        pickPanel.addView(pointDetails, marginParams(bottom = 9))
        pickPanel.addView(actionChip("⌖  Выбрать точку сейчас", outlined = true) {
            selectedMode = TapLoopConfig.MODE_PICK
            saveFormToPreferences()
            updateModeUi()
            val service = AutoClickAccessibilityService.activeService
            if (service == null) {
                showMessage("Сначала включи службу TapLoop в настройках специальных возможностей.")
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else if (!Settings.canDrawOverlays(this)) {
                askOverlayPermission()
            } else {
                service.beginCoordinateSelection()
            }
        })
        pointCard.addView(pickPanel, marginParams(bottom = 1))
        root.addView(pointCard, marginParams(bottom = 14))

        val controlCard = card()
        controlCard.addView(sectionHeading("03", "Управление", "Можно запускать и с плавающей панели"))
        launchButton = actionChip("▶   Запустить автокликер", outlined = false) { toggleMainControl() }.apply {
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(15), dp(14), dp(15))
        }
        controlCard.addView(launchButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)).apply {
            bottomMargin = dp(8)
        })
        controlCard.addView(actionChip("■   Остановить", outlined = true) {
            AutoClickAccessibilityService.activeService?.stopClicking()
            updateStatus()
        }.apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))
        root.addView(controlCard, marginParams(bottom = 14))

        val permissions = card()
        permissions.addView(sectionHeading("04", "Первый запуск", "Два разрешения, затем всё управление под рукой"))
        permissions.addView(actionChip("Включить службу специальных возможностей", outlined = true) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, marginParams(bottom = 8))
        permissions.addView(actionChip("Разрешить отображение поверх окон", outlined = true) {
            askOverlayPermission()
        }, marginParams(bottom = 10))
        permissions.addView(text(
            "Плавающая панель видна, пока включена служба TapLoop и разрешено отображение поверх окон. Значок ▶ запускает, ■ останавливает, ⌖ выбирает точку.",
            12f, colors.secondary, false
        ))
        root.addView(permissions, marginParams(bottom = 18))

        root.addView(text("TAPLOOP  •  BUILD 1.1", 10f, colors.muted, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.14f
            setPadding(0, dp(4), 0, dp(4))
        })

        setContentView(scroll)
        updateModeUi()
        updatePointDetails()
        updateStatus()
    }

    private fun toggleMainControl() {
        val service = AutoClickAccessibilityService.activeService
        if (service?.isRunning() == true) {
            service.stopClicking()
            updateStatus()
        } else {
            startClicking()
        }
    }

    private fun startClicking() {
        if (!isAccessibilityEnabled()) {
            showMessage("Сначала включи TapLoop в настройках специальных возможностей.")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            showMessage("Разреши плавающее окно, чтобы панель управления всегда отображалась поверх приложений.")
            askOverlayPermission()
            return
        }

        saveFormToPreferences()
        val service = AutoClickAccessibilityService.activeService
        if (service == null) {
            showMessage("Служба подключается. Вернись в TapLoop и нажми запуск ещё раз.")
            return
        }
        if (selectedMode == TapLoopConfig.MODE_PICK && !prefs.getBoolean(TapLoopConfig.POINT_SELECTED, false)) {
            service.ensureFloatingControls()
            service.beginCoordinateSelection()
            return
        }

        val interval = intervalInput.text.toString().toLongOrNull()?.coerceIn(100L, 60_000L) ?: 500L
        val x = xInput.text.toString().toIntOrNull()?.coerceAtLeast(0) ?: 0
        val y = yInput.text.toString().toIntOrNull()?.coerceAtLeast(0) ?: 0
        intervalInput.setText(interval.toString())
        xInput.setText(x.toString())
        yInput.setText(y.toString())
        prefs.edit().putLong(TapLoopConfig.INTERVAL, interval).putInt(TapLoopConfig.X, x).putInt(TapLoopConfig.Y, y).apply()
        val started = service.startClicking(interval, x, y, selectedMode)
        if (!started) showMessage("Не удалось запустить. Проверь разрешение плавающих окон и выбранную точку.")
        updateStatus()
    }

    private fun saveFormToPreferences() {
        if (!::intervalInput.isInitialized) return
        val interval = intervalInput.text.toString().toLongOrNull()?.coerceIn(100L, 60_000L) ?: 500L
        val x = if (::xInput.isInitialized) xInput.text.toString().toIntOrNull()?.coerceAtLeast(0) ?: 0 else prefs.getInt(TapLoopConfig.X, 0)
        val y = if (::yInput.isInitialized) yInput.text.toString().toIntOrNull()?.coerceAtLeast(0) ?: 0 else prefs.getInt(TapLoopConfig.Y, 0)
        prefs.edit()
            .putLong(TapLoopConfig.INTERVAL, interval)
            .putInt(TapLoopConfig.X, x)
            .putInt(TapLoopConfig.Y, y)
            .putString(TapLoopConfig.MODE, selectedMode)
            .apply()
    }

    private fun updateModeUi() {
        if (!::coordinateFields.isInitialized) return
        val colors = palette
        coordinateFields.visibility = if (selectedMode == TapLoopConfig.MODE_MANUAL) View.VISIBLE else View.GONE
        pickPanel.visibility = if (selectedMode == TapLoopConfig.MODE_PICK) View.VISIBLE else View.GONE
        centerPanel.visibility = if (selectedMode == TapLoopConfig.MODE_CENTER) View.VISIBLE else View.GONE
        centerPanel.text = when (selectedMode) {
            TapLoopConfig.MODE_CENTER -> "Автокликер будет нажимать в центре экрана."
            TapLoopConfig.MODE_MANUAL -> "Укажи физические координаты экрана в пикселях."
            else -> "Выбери точку касанием прямо поверх нужного приложения."
        }
        fun styleMode(button: TextView, isSelected: Boolean) {
            button.background = rounded(if (isSelected) colors.accent else colors.surfaceAlt, 14, if (isSelected) colors.accent else colors.border)
            button.setTextColor(if (isSelected) colors.accentText else colors.secondary)
            button.typeface = if (isSelected) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
        styleMode(modeCenterButton, selectedMode == TapLoopConfig.MODE_CENTER)
        styleMode(modeManualButton, selectedMode == TapLoopConfig.MODE_MANUAL)
        styleMode(modePickButton, selectedMode == TapLoopConfig.MODE_PICK)
        updatePointDetails()
        AutoClickAccessibilityService.activeService?.refreshFloatingControls()
    }

    private fun updatePointDetails() {
        if (!::pointDetails.isInitialized) return
        val hasPoint = prefs.getBoolean(TapLoopConfig.POINT_SELECTED, false)
        pointDetails.text = if (hasPoint) {
            "Сохранённая точка: X=${prefs.getInt(TapLoopConfig.X, 0)} · Y=${prefs.getInt(TapLoopConfig.Y, 0)}"
        } else "Точка ещё не выбрана"
    }

    private fun updateStatus() {
        if (!::status.isInitialized) return
        val enabled = isAccessibilityEnabled()
        val overlay = Settings.canDrawOverlays(this)
        val service = AutoClickAccessibilityService.activeService
        status.text = when {
            service?.isRunning() == true -> "●  Автокликер работает"
            enabled && overlay && service != null -> "●  Готов к запуску"
            enabled -> "●  Служба включена"
            else -> "●  Нужно выдать разрешения"
        }
        status.setTextColor(when {
            service?.isRunning() == true -> Color.rgb(244, 63, 94)
            enabled && overlay && service != null -> palette.accent
            else -> palette.text
        })
        statusDetail.text = "Служба: ${if (enabled) "включена" else "выключена"}   ·   Окна поверх приложений: ${if (overlay) "разрешены" else "не разрешены"}"
        if (::launchButton.isInitialized) {
            launchButton.text = if (service?.isRunning() == true) "■   Остановить автокликер" else "▶   Запустить автокликер"
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getInt(contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 0) == 1
        if (!enabled) return false
        val setting = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val component = ComponentName(this, AutoClickAccessibilityService::class.java).flattenToString()
        return setting.split(':').any { it.equals(component, ignoreCase = true) }
    }

    private fun askOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else {
            AutoClickAccessibilityService.activeService?.ensureFloatingControls()
            showMessage("Разрешение уже выдано.")
        }
    }

    private fun modeChip(label: String, mode: String) = text(label, 12f, palette.secondary, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(4), 0, dp(4), 0)
        background = rounded(palette.surfaceAlt, 14, palette.border)
        setOnClickListener {
            saveFormToPreferences()
            selectedMode = mode
            prefs.edit().putString(TapLoopConfig.MODE, mode).apply()
            updateModeUi()
        }
    }

    private fun sectionHeading(number: String, title: String, subtitle: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        val numberAndTitle = LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        numberAndTitle.addView(text(number, 11f, palette.accent, true).apply {
            gravity = Gravity.CENTER
            background = rounded(palette.surfaceAlt, 10, palette.border)
            setPadding(dp(7), dp(5), dp(7), dp(5))
        })
        numberAndTitle.addView(text(title, 18f, palette.text, true).apply {
            setPadding(dp(9), 0, 0, 0)
        })
        addView(numberAndTitle)
        addView(text(subtitle, 12f, palette.secondary, false).apply {
            setPadding(0, dp(5), 0, dp(14))
        })
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(palette.surface, 22, palette.border)
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun numberField(value: String, hintText: String) = EditText(this).apply {
        setSingleLine(true)
        inputType = InputType.TYPE_CLASS_NUMBER
        setText(value)
        hint = hintText
        textSize = 15f
        setTextColor(palette.text)
        setHintTextColor(palette.muted)
        setPadding(dp(13), dp(9), dp(13), dp(9))
        background = rounded(palette.field, 14, palette.border)
    }

    private fun actionChip(label: String, outlined: Boolean, action: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 13f
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        typeface = if (outlined) Typeface.create("sans-serif-medium", Typeface.NORMAL) else Typeface.DEFAULT_BOLD
        setTextColor(if (outlined) palette.text else palette.accentText)
        background = rounded(if (outlined) palette.surfaceAlt else palette.accent, 15, if (outlined) palette.border else palette.accent)
        isClickable = true
        isFocusable = true
        setOnClickListener { action() }
    }

    private fun dot(color: Int) = View(this).apply {
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }
        layoutParams = LinearLayout.LayoutParams(dp(8), dp(8))
    }

    private fun rounded(color: Int, radiusDp: Int, strokeColor: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        setStroke(dp(1), strokeColor)
    }

    private fun marginParams(bottom: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(bottom)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun showMessage(message: String) {
        AlertDialog.Builder(this).setMessage(message).setPositiveButton("Понятно", null).show()
    }
}
