package com.example.taploop

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class AutoClickAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile
        var activeService: AutoClickAccessibilityService? = null
            private set
    }

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var intervalMs = 500L
    private var requestedX = 0
    private var requestedY = 0
    private var tapMode = TapLoopConfig.MODE_CENTER

    private var overlayManager: WindowManager? = null
    private var floatingPanel: LinearLayout? = null
    private var toggleButton: TextView? = null
    private var targetButton: TextView? = null
    private var pickerView: View? = null
    private var pickerManager: WindowManager? = null
    private var resumeAfterPicking = false

    private val clickLoop = object : Runnable {
        override fun run() {
            if (!running) return
            @Suppress("DEPRECATION")
            val display = (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay
            @Suppress("DEPRECATION")
            val realMetrics = android.util.DisplayMetrics().also { display.getRealMetrics(it) }
            val x = if (tapMode == TapLoopConfig.MODE_CENTER) realMetrics.widthPixels / 2f else requestedX.toFloat()
            val y = if (tapMode == TapLoopConfig.MODE_CENTER) realMetrics.heightPixels / 2f else requestedY.toFloat()
            val boundedX = x.coerceIn(1f, (realMetrics.widthPixels - 1).coerceAtLeast(1).toFloat())
            val boundedY = y.coerceIn(1f, (realMetrics.heightPixels - 1).coerceAtLeast(1).toFloat())
            val path = Path().apply { moveTo(boundedX, boundedY) }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 45))
                .build()
            dispatchGesture(gesture, null, null)
            handler.postDelayed(this, intervalMs)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        activeService = this
        ensureFloatingControls()
    }

    fun isRunning(): Boolean = running

    fun startClicking(interval: Long, x: Int, y: Int, mode: String): Boolean {
        if (!Settings.canDrawOverlays(this)) return false
        if (!ensureFloatingControls()) return false

        intervalMs = interval.coerceIn(100L, 60_000L)
        tapMode = mode
        requestedX = x.coerceAtLeast(0)
        requestedY = y.coerceAtLeast(0)
        if (tapMode == TapLoopConfig.MODE_PICK) {
            val prefs = getSharedPreferences(TapLoopConfig.PREFS, MODE_PRIVATE)
            if (!prefs.getBoolean(TapLoopConfig.POINT_SELECTED, false)) return false
        }

        running = true
        handler.removeCallbacks(clickLoop)
        refreshFloatingControls()
        handler.post(clickLoop)
        return true
    }

    fun stopClicking() {
        running = false
        handler.removeCallbacks(clickLoop)
        refreshFloatingControls()
    }

    /** Keeps the floating start/stop control visible while the accessibility service is enabled. */
    fun ensureFloatingControls(): Boolean {
        if (!Settings.canDrawOverlays(this)) return false
        if (floatingPanel != null) {
            refreshFloatingControls()
            return true
        }

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(5), dp(5), dp(5), dp(5))
            background = rounded(Color.rgb(18, 27, 45), 30)
            elevation = dp(10).toFloat()
        }
        val startStop = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(16, 185, 129), 25)
            contentDescription = "Запустить или остановить автокликер"
            setOnClickListener { onFloatingToggle() }
        }
        val target = TextView(this).apply {
            gravity = Gravity.CENTER
            text = "⌖"
            textSize = 29f
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(99, 102, 241), 25)
            contentDescription = "Выбрать точку на экране"
            setOnClickListener { beginCoordinateSelection() }
        }
        panel.addView(startStop, LinearLayout.LayoutParams(dp(48), dp(48)).apply {
            marginEnd = dp(5)
        })
        panel.addView(target, LinearLayout.LayoutParams(dp(44), dp(44)))

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(12)
            y = dp(118)
        }

        return try {
            wm.addView(panel, params)
            overlayManager = wm
            floatingPanel = panel
            toggleButton = startStop
            targetButton = target
            refreshFloatingControls()
            true
        } catch (_: Exception) {
            floatingPanel = null
            toggleButton = null
            targetButton = null
            overlayManager = null
            false
        }
    }

    fun refreshFloatingControls() {
        toggleButton?.apply {
            text = if (running) "■" else "▶"
            background = rounded(if (running) Color.rgb(244, 63, 94) else Color.rgb(16, 185, 129), 25)
            contentDescription = if (running) "Остановить автокликер" else "Запустить автокликер"
        }
        val prefs = getSharedPreferences(TapLoopConfig.PREFS, MODE_PRIVATE)
        targetButton?.visibility = if (prefs.getString(TapLoopConfig.MODE, TapLoopConfig.MODE_CENTER) == TapLoopConfig.MODE_PICK) View.VISIBLE else View.GONE
    }

    private fun onFloatingToggle() {
        if (running) {
            stopClicking()
            Toast.makeText(this, "Автокликер остановлен", Toast.LENGTH_SHORT).show()
            return
        }

        val prefs = getSharedPreferences(TapLoopConfig.PREFS, MODE_PRIVATE)
        val mode = prefs.getString(TapLoopConfig.MODE, TapLoopConfig.MODE_CENTER) ?: TapLoopConfig.MODE_CENTER
        val interval = prefs.getLong(TapLoopConfig.INTERVAL, 500L)
        val x = prefs.getInt(TapLoopConfig.X, 0)
        val y = prefs.getInt(TapLoopConfig.Y, 0)
        if (mode == TapLoopConfig.MODE_PICK && !prefs.getBoolean(TapLoopConfig.POINT_SELECTED, false)) {
            Toast.makeText(this, "Сначала выбери точку значком ⌖", Toast.LENGTH_SHORT).show()
            beginCoordinateSelection()
            return
        }
        if (!startClicking(interval, x, y, mode)) {
            Toast.makeText(this, "Не удалось запустить. Проверь разрешение плавающих окон и точку нажатия.", Toast.LENGTH_LONG).show()
        }
    }

    /** Shows a touch-through-to-coordinate selection layer after the user presses the target icon. */
    fun beginCoordinateSelection() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Разреши отображение поверх других приложений", Toast.LENGTH_LONG).show()
            return
        }
        if (pickerView != null) return

        resumeAfterPicking = running
        if (running) {
            running = false
            handler.removeCallbacks(clickLoop)
            refreshFloatingControls()
        }

        val chooser = FrameLayout(this).apply {
            setBackgroundColor(Color.argb(38, 7, 12, 25))
        }
        val hint = TextView(this).apply {
            text = "КОСНИСЬ НУЖНОЙ ТОЧКИ\n\nTapLoop сохранит координаты для следующих нажатий"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(dp(20), dp(16), dp(20), dp(16))
            background = rounded(Color.rgb(18, 27, 45), 20)
        }
        chooser.addView(hint, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP
        ).apply {
            setMargins(dp(20), dp(65), dp(20), 0)
        })
        chooser.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                val px = event.rawX.toInt().coerceAtLeast(1)
                val py = event.rawY.toInt().coerceAtLeast(1)
                savePickedPoint(px, py)
            }
            true
        }

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }
        try {
            wm.addView(chooser, params)
            pickerManager = wm
            pickerView = chooser
        } catch (_: Exception) {
            pickerView = null
            pickerManager = null
            Toast.makeText(this, "Не удалось открыть выбор координат", Toast.LENGTH_LONG).show()
            if (resumeAfterPicking) {
                running = true
                handler.post(clickLoop)
            }
            refreshFloatingControls()
        }
    }

    private fun savePickedPoint(x: Int, y: Int) {
        requestedX = x
        requestedY = y
        tapMode = TapLoopConfig.MODE_PICK
        getSharedPreferences(TapLoopConfig.PREFS, MODE_PRIVATE).edit()
            .putInt(TapLoopConfig.X, x)
            .putInt(TapLoopConfig.Y, y)
            .putString(TapLoopConfig.MODE, TapLoopConfig.MODE_PICK)
            .putBoolean(TapLoopConfig.POINT_SELECTED, true)
            .apply()

        removeCoordinatePicker()
        refreshFloatingControls()
        Toast.makeText(this, "Точка сохранена: X=$x, Y=$y", Toast.LENGTH_SHORT).show()
        if (resumeAfterPicking) {
            running = true
            handler.removeCallbacks(clickLoop)
            handler.post(clickLoop)
        }
        resumeAfterPicking = false
    }

    private fun removeCoordinatePicker() {
        val view = pickerView ?: return
        try {
            pickerManager?.removeView(view)
        } catch (_: Exception) {
            // The system may already have removed the overlay.
        }
        pickerView = null
        pickerManager = null
    }

    private fun removeFloatingControls() {
        val panel = floatingPanel ?: return
        try {
            overlayManager?.removeView(panel)
        } catch (_: Exception) {
            // The system may already have removed the overlay.
        }
        floatingPanel = null
        toggleButton = null
        targetButton = null
        overlayManager = null
    }

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() {
        stopClicking()
    }

    override fun onDestroy() {
        stopClicking()
        removeCoordinatePicker()
        removeFloatingControls()
        if (activeService === this) activeService = null
        super.onDestroy()
    }
}
