package com.example.taploop

object TapLoopConfig {
    const val PREFS = "taploop_prefs"
    const val DARK_THEME = "dark_theme"
    const val INTERVAL = "interval_ms"
    const val X = "tap_x"
    const val Y = "tap_y"
    const val MODE = "tap_mode"
    const val POINT_SELECTED = "point_selected"

    const val MODE_CENTER = "center"
    const val MODE_MANUAL = "manual"
    const val MODE_PICK = "pick"
}
