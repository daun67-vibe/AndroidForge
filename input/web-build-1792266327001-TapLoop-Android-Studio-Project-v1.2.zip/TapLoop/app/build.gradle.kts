plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.taploop"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.taploop"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "1.2"
    }

    buildTypes {
        getByName("debug") {
            // AndroidForge signs the unsigned APK in a trusted post-build step.
            // The private key is stored in GitHub Actions Secrets, never in this public source ZIP.
            signingConfig = null
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
