package com.example.taploop

object TapLoopConfig {
    const val PREFS = "taploop_prefs"
    const val DARK_THEME = "dark_theme"
    const val INTERVAL = "interval_ms"
    const val X = "tap_x"
    const val Y = "tap_y"
    const val MODE = "tap_mode"
    const val POINT_SELECTED = "point_selected"
    const val INTERVAL_UNIT = "interval_unit"
    const val STOP_CONDITION = "stop_condition"
    const val STOP_LIMIT = "stop_limit"
    const val STOP_TIME_UNIT = "stop_time_unit"
    const val PANEL_X = "panel_x"
    const val PANEL_Y = "panel_y"

    const val MODE_CENTER = "center"
    const val MODE_MANUAL = "manual"
    const val MODE_PICK = "pick"

    const val STOP_MANUAL = "manual"
    const val STOP_TIME = "time"
    const val STOP_COUNT = "count"
}
