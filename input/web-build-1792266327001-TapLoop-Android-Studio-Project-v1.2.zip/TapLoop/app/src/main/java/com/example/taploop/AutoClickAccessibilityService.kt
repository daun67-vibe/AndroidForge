package com.example.taploop

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.InputType
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowInsets
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.roundToLong
import java.util.Locale

class AutoClickAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile
        var activeService: AutoClickAccessibilityService? = null
            private set
    }

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var intervalMs = 500L
    private var requestedX = 0
    private var requestedY = 0
    private var tapMode = TapLoopConfig.MODE_CENTER
    private var stopCondition = TapLoopConfig.STOP_MANUAL
    private var stopLimit = 0L
    private var startedAt = 0L
    private var clicksDone = 0L

    private var overlayManager: WindowManager? = null
    private var floatingPanel: LinearLayout? = null
    private var toolbar: LinearLayout? = null
    private var startStopButton: TextView? = null
    private var settingsButton: TextView? = null
    private var moveButton: TextView? = null
    private var compactControls: LinearLayout? = null
    private var closePanelButton: TextView? = null
    private var restorePanelButton: TextView? = null
    private var settingsPanel: LinearLayout? = null
    private var intervalEditor: EditText? = null
    private var intervalUnitSpinner: Spinner? = null
    private var stopConditionSpinner: Spinner? = null
    private var stopLimitEditor: EditText? = null
    private var stopTimeUnitSpinner: Spinner? = null
    private var stopLimitSuffix: TextView? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var settingsExpanded = false
    private var compactMode = false

    private var pickerView: View? = null
    private var pickerManager: WindowManager? = null
    private var resumeAfterPicking = false

    private val stopDeadlineRunnable = Runnable {
        if (running && stopCondition == TapLoopConfig.STOP_TIME) {
            stopClicking("Время вышло, автокликер остановлен")
        }
    }

    private val clickLoop = object : Runnable {
        override fun run() {
            if (!running) return
            if (stopCondition == TapLoopConfig.STOP_COUNT && clicksDone >= stopLimit) {
                stopClicking("Лимит нажатий достигнут")
                return
            }

            @Suppress("DEPRECATION")
            val display = (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay
            @Suppress("DEPRECATION")
            val metrics = DisplayMetrics().also { display.getRealMetrics(it) }
            val x = if (tapMode == TapLoopConfig.MODE_CENTER) metrics.widthPixels / 2f else requestedX.toFloat()
            val y = if (tapMode == TapLoopConfig.MODE_CENTER) metrics.heightPixels / 2f else requestedY.toFloat()
            val boundedX = x.coerceIn(1f, (metrics.widthPixels - 1).coerceAtLeast(1).toFloat())
            val boundedY = y.coerceIn(1f, (metrics.heightPixels - 1).coerceAtLeast(1).toFloat())
            val path = Path().apply { moveTo(boundedX, boundedY) }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 8))
                .build()
            dispatchGesture(gesture, null, null)
            clicksDone++

            if (stopCondition == TapLoopConfig.STOP_COUNT && clicksDone >= stopLimit) {
                stopClicking("Лимит нажатий достигнут")
                return
            }
            handler.postDelayed(this, intervalMs)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        activeService = this
        ensureFloatingControls()
    }

    fun isRunning(): Boolean = running

    fun startClicking(interval: Long, x: Int, y: Int, mode: String): Boolean {
        if (!Settings.canDrawOverlays(this)) return false
        if (!ensureFloatingControls()) return false

        val prefs = getSharedPreferences(TapLoopConfig.PREFS, MODE_PRIVATE)
        intervalMs = interval.coerceIn(20L, 86_400_000L)
        tapMode = mode
        requestedX = x.coerceAtLeast(0)
        requestedY = y.coerceAtLeast(0)
        stopCondition = prefs.getString(TapLoopConfig.STOP_CONDITION, TapLoopConfig.STOP_MANUAL)
            ?: TapLoopConfig.STOP_MANUAL
        stopLimit = prefs.getLong(TapLoopConfig.STOP_LIMIT, 0L).coerceAtLeast(0L)

        if (tapMode == TapLoopConfig.MODE_PICK && !prefs.getBoolean(TapLoopConfig.POINT_SELECTED, false)) return false
        if (stopCondition == TapLoopConfig.STOP_TIME && stopLimit < 1L) return false
        if (stopCondition == TapLoopConfig.STOP_COUNT && stopLimit < 1L) return false

        running = true
        clicksDone = 0L
        startedAt = SystemClock.elapsedRealtime()
        handler.removeCallbacks(clickLoop)
        handler.removeCallbacks(stopDeadlineRunnable)
        refreshFloatingControls()
        if (stopCondition == TapLoopConfig.STOP_TIME) handler.postDelayed(stopDeadlineRunnable, stopLimit)
        handler.post(clickLoop)
        return true
    }

    fun stopClicking(message: String? = null) {
        val wasRunning = running
        running = false
        handler.removeCallbacks(clickLoop)
        handler.removeCallbacks(stopDeadlineRunnable)
        refreshFloatingControls()
        if (wasRunning && !message.isNullOrBlank()) Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    /** Keeps the floating controls visible while the accessibility service is enabled. */
    fun ensureFloatingControls(): Boolean {
        if (!Settings.canDrawOverlays(this)) return false
        if (floatingPanel != null) {
            refreshFloatingControls()
            return true
        }

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(6), dp(7), dp(6), dp(7))
            background = rounded(Color.rgb(16, 24, 41), 23, Color.rgb(45, 61, 85))
            elevation = dp(12).toFloat()
            clipChildren = false
            clipToPadding = false
        }

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val toggle = overlayButton("▶", Color.rgb(16, 185, 129), "Запустить автокликер")
        val settings = overlayButton("⚙", Color.rgb(59, 130, 246), "Настройки автокликера")
        val move = overlayButton("↕", Color.rgb(100, 116, 139), "Переместить панель: потяни кнопку")
        controls.addView(toggle, controlParams(bottom = 6))
        controls.addView(settings, controlParams(bottom = 6))
        controls.addView(move, controlParams())
        panel.addView(controls)

        val compact = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        val close = overlayButton("×", Color.rgb(244, 63, 94), "Закрыть панель и остановить автокликер")
        val restore = overlayButton("▣", Color.rgb(59, 130, 246), "Развернуть панель; удерживай и тяни для перемещения")
        compact.addView(close, compactButtonParams(end = 5))
        compact.addView(restore, compactButtonParams())
        panel.addView(compact)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = getSharedPreferences(TapLoopConfig.PREFS, MODE_PRIVATE).getInt(TapLoopConfig.PANEL_X, dp(12)).coerceAtLeast(0)
            y = getSharedPreferences(TapLoopConfig.PREFS, MODE_PRIVATE).getInt(TapLoopConfig.PANEL_Y, dp(110)).coerceAtLeast(dp(28))
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }

        return try {
            wm.addView(panel, params)
            overlayManager = wm
            floatingPanel = panel
            toolbar = controls
            startStopButton = toggle
            settingsButton = settings
            moveButton = move
            compactControls = compact
            closePanelButton = close
            restorePanelButton = restore
            overlayParams = params

            buildFloatingSettings(panel)
            toggle.setOnClickListener { onFloatingToggle() }
            settings.setOnClickListener { toggleSettings() }
            move.setOnTouchListener { _, event -> handleDragTouch(event, onTap = { enterCompactMode() }) }
            close.setOnClickListener {
                stopClicking()
                removeFloatingControls()
                Toast.makeText(this, "Панель скрыта. Открой TapLoop, чтобы вернуть её.", Toast.LENGTH_SHORT).show()
            }
            restore.setOnTouchListener { _, event -> handleDragTouch(event, onTap = { exitCompactMode() }) }
            refreshFloatingControls()
            true
        } catch (_: Exception) {
            floatingPanel = null
            toolbar = null
            startStopButton = null
            settingsButton = null
            moveButton = null
            compactControls = null
            closePanelButton = null
            restorePanelButton = null
            settingsPanel = null
            overlayManager = null
            overlayParams = null
            false
        }
    }

    private fun buildFloatingSettings(panel: LinearLayout) {
        val prefs = getSharedPreferences(TapLoopConfig.PREFS, MODE_PRIVATE)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dp(10), dp(10), dp(10), dp(6))
            background = rounded(Color.rgb(24, 35, 56), 17, Color.rgb(54, 72, 100))
            layoutParams = LinearLayout.LayoutParams(settingsWidth(), ViewGroupParams.WRAP_CONTENT).apply {
                topMargin = dp(8)
            }
        }
        card.addView(label("НАСТРОЙКИ", 11f, Color.rgb(94, 234, 212), true), itemParams(bottom = 8))
        card.addView(label("Интервал между нажатиями", 12f, Color.WHITE, true), itemParams(bottom = 5))

        val intervalRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val interval = numericField("500", decimal = true)
        val intervalUnit = unitSpinner(listOf("мс", "сек", "мин"), prefs.getInt(TapLoopConfig.INTERVAL_UNIT, 0))
        intervalRow.addView(interval, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(6) })
        intervalRow.addView(intervalUnit, LinearLayout.LayoutParams(dp(82), dp(42)))
        card.addView(intervalRow, itemParams(bottom = 12))

        card.addView(label("Остановить", 12f, Color.WHITE, true), itemParams(bottom = 5))
        val stopItems = listOf("Пока не нажму стоп", "Через время", "После N кликов")
        val conditionIndex = when (prefs.getString(TapLoopConfig.STOP_CONDITION, TapLoopConfig.STOP_MANUAL)) {
            TapLoopConfig.STOP_TIME -> 1
            TapLoopConfig.STOP_COUNT -> 2
            else -> 0
        }
        val conditionSpinner = unitSpinner(stopItems, conditionIndex)
        card.addView(conditionSpinner, itemParams(bottom = 8, height = 44))

        val limitRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val limitField = numericField("1", decimal = true)
        val timeUnit = unitSpinner(listOf("мс", "сек", "мин"), prefs.getInt(TapLoopConfig.STOP_TIME_UNIT, 1))
        val suffix = label("кликов", 11f, Color.rgb(181, 196, 216), true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(4), 0, dp(2), 0)
        }
        limitRow.addView(limitField, LinearLayout.LayoutParams(0, dp(42), 1f))
        limitRow.addView(timeUnit, LinearLayout.LayoutParams(dp(82), dp(42)).apply { marginStart = dp(5) })
        limitRow.addView(suffix, LinearLayout.LayoutParams(dp(52), dp(42)))
        card.addView(limitRow, itemParams(bottom = 10))

        val apply = overlayAction("СОХРАНИТЬ", Color.rgb(45, 212, 191), Color.rgb(7, 25, 34)) {
            saveFloatingSettings()
        }
        card.addView(apply, itemParams(bottom = 7, height = 42))
        val pickPoint = overlayAction("⌖  Выбрать точку", Color.rgb(40, 55, 81), Color.WHITE) {
            saveFloatingSettings(closeAfter = true, pickPointAfter = true)
        }
        card.addView(pickPoint, itemParams(bottom = 3, height = 42))

        intervalEditor = interval
        intervalUnitSpinner = intervalUnit
        stopConditionSpinner = conditionSpinner
        stopLimitEditor = limitField
        stopTimeUnitSpinner = timeUnit
        stopLimitSuffix = suffix
        settingsPanel = card
        panel.addView(card)

        val unitIndex = prefs.getInt(TapLoopConfig.INTERVAL_UNIT, 0).coerceIn(0, 2)
        interval.setText(formatAmount(prefs.getLong(TapLoopConfig.INTERVAL, 500L) / unitMultiplier(unitIndex).toDouble()))
        val stopTimeIndex = prefs.getInt(TapLoopConfig.STOP_TIME_UNIT, 1).coerceIn(0, 2)
        val stopLimitMs = prefs.getLong(TapLoopConfig.STOP_LIMIT, 60_000L).takeIf { it > 0L } ?: 60_000L
        limitField.setText(if (conditionIndex == 2) stopLimitMs.toString() else formatAmount(stopLimitMs / unitMultiplier(stopTimeIndex).toDouble()))
        conditionSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                updateStopLimitControls(position)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        updateStopLimitControls(conditionIndex)
    }

    private fun updateStopLimitControls(position: Int) {
        val timed = position == 1
        val counted = position == 2
        stopTimeUnitSpinner?.visibility = if (timed) View.VISIBLE else View.GONE
        stopLimitSuffix?.visibility = if (counted) View.VISIBLE else View.GONE
        stopLimitEditor?.visibility = if (timed || counted) View.VISIBLE else View.GONE
    }

    private fun toggleSettings() {
        if (compactMode) exitCompactMode()
        settingsExpanded = !settingsExpanded
        settingsPanel?.visibility = if (settingsExpanded) View.VISIBLE else View.GONE
        if (settingsExpanded) loadFloatingSettings()
        updateWindowFlags()
        overlayPanelChanged()
    }

    private fun loadFloatingSettings() {
        val prefs = getSharedPreferences(TapLoopConfig.PREFS, MODE_PRIVATE)
        val intervalUnit = prefs.getInt(TapLoopConfig.INTERVAL_UNIT, 0).coerceIn(0, 2)
        intervalUnitSpinner?.setSelection(intervalUnit)
        intervalEditor?.setText(formatAmount(prefs.getLong(TapLoopConfig.INTERVAL, 500L) / unitMultiplier(intervalUnit).toDouble()))
        val condition = prefs.getString(TapLoopConfig.STOP_CONDITION, TapLoopConfig.STOP_MANUAL)
        val conditionIndex = when (condition) {
            TapLoopConfig.STOP_TIME -> 1
            TapLoopConfig.STOP_COUNT -> 2
            else -> 0
        }
        stopConditionSpinner?.setSelection(conditionIndex)
        val timeUnit = prefs.getInt(TapLoopConfig.STOP_TIME_UNIT, 1).coerceIn(0, 2)
        stopTimeUnitSpinner?.setSelection(timeUnit)
        val limit = prefs.getLong(TapLoopConfig.STOP_LIMIT, 60_000L).takeIf { it > 0L } ?: 60_000L
        stopLimitEditor?.setText(if (conditionIndex == 2) limit.toString() else formatAmount(limit / unitMultiplier(timeUnit).toDouble()))
        updateStopLimitControls(conditionIndex)
    }

    private fun saveFloatingSettings(closeAfter: Boolean = true, pickPointAfter: Boolean = false) {
        val amount = intervalEditor?.text?.toString()?.replace(',', '.')?.toDoubleOrNull()
        if (amount == null || !amount.isFinite() || amount <= 0.0) {
            Toast.makeText(this, "Введи корректный интервал", Toast.LENGTH_SHORT).show()
            return
        }
        val intervalUnit = intervalUnitSpinner?.selectedItemPosition?.coerceIn(0, 2) ?: 0
        val interval = (amount * unitMultiplier(intervalUnit)).roundToLong().coerceIn(20L, 86_400_000L)
        val conditionPosition = stopConditionSpinner?.selectedItemPosition ?: 0
        val condition = when (conditionPosition) {
            1 -> TapLoopConfig.STOP_TIME
            2 -> TapLoopConfig.STOP_COUNT
            else -> TapLoopConfig.STOP_MANUAL
        }
        val stopLimit = if (condition == TapLoopConfig.STOP_MANUAL) 0L else {
            val raw = stopLimitEditor?.text?.toString()?.replace(',', '.')?.toDoubleOrNull()
            if (raw == null || !raw.isFinite() || raw <= 0.0) {
                Toast.makeText(this, "Введи положительное значение для остановки", Toast.LENGTH_SHORT).show()
                return
            }
            if (condition == TapLoopConfig.STOP_COUNT) raw.roundToLong().coerceIn(1L, 1_000_000_000L)
            else {
                val unit = stopTimeUnitSpinner?.selectedItemPosition?.coerceIn(0, 2) ?: 1
                (raw * unitMultiplier(unit)).roundToLong().coerceIn(1L, 604_800_000L)
            }
        }
        val stopTimeUnit = stopTimeUnitSpinner?.selectedItemPosition?.coerceIn(0, 2) ?: 1
        getSharedPreferences(TapLoopConfig.PREFS, MODE_PRIVATE).edit()
            .putLong(TapLoopConfig.INTERVAL, interval)
            .putInt(TapLoopConfig.INTERVAL_UNIT, intervalUnit)
            .putString(TapLoopConfig.STOP_CONDITION, condition)
            .putLong(TapLoopConfig.STOP_LIMIT, stopLimit)
            .putInt(TapLoopConfig.STOP_TIME_UNIT, stopTimeUnit)
            .apply()
        intervalEditor?.setText(formatAmount(interval / unitMultiplier(intervalUnit).toDouble()))

        if (closeAfter) closeSettingsPanel()
        Toast.makeText(this, "Настройки сохранены · ${interval} мс между нажатиями", Toast.LENGTH_SHORT).show()
        if (pickPointAfter) beginCoordinateSelection()
    }

    private fun closeSettingsPanel() {
        settingsExpanded = false
        settingsPanel?.visibility = View.GONE
        (getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)?.hideSoftInputFromWindow(intervalEditor?.windowToken, 0)
        intervalEditor?.clearFocus()
        stopLimitEditor?.clearFocus()
        updateWindowFlags()
        overlayPanelChanged()
    }

    private fun onFloatingToggle() {
        if (running) {
            stopClicking("Автокликер остановлен")
            return
        }
        val prefs = getSharedPreferences(TapLoopConfig.PREFS, MODE_PRIVATE)
        val mode = prefs.getString(TapLoopConfig.MODE, TapLoopConfig.MODE_CENTER) ?: TapLoopConfig.MODE_CENTER
        val interval = prefs.getLong(TapLoopConfig.INTERVAL, 500L)
        val x = prefs.getInt(TapLoopConfig.X, 0)
        val y = prefs.getInt(TapLoopConfig.Y, 0)
        val condition = prefs.getString(TapLoopConfig.STOP_CONDITION, TapLoopConfig.STOP_MANUAL)
        val limit = prefs.getLong(TapLoopConfig.STOP_LIMIT, 0L)
        if (mode == TapLoopConfig.MODE_PICK && !prefs.getBoolean(TapLoopConfig.POINT_SELECTED, false)) {
            Toast.makeText(this, "Сначала выбери точку в настройках панели", Toast.LENGTH_SHORT).show()
            toggleSettings()
            return
        }
        if ((condition == TapLoopConfig.STOP_TIME || condition == TapLoopConfig.STOP_COUNT) && limit <= 0L) {
            Toast.makeText(this, "Открой настройки и задай условие остановки", Toast.LENGTH_SHORT).show()
            toggleSettings()
            return
        }
        if (!startClicking(interval, x, y, mode)) {
            Toast.makeText(this, "Не удалось запустить. Проверь разрешения и точку нажатия.", Toast.LENGTH_LONG).show()
        }
    }

    /** Rebuild the WindowManager flags whenever the settings panel needs text input. */
    private fun updateWindowFlags() {
        val wm = overlayManager ?: return
        val panel = floatingPanel ?: return
        val params = overlayParams ?: return
        params.flags = if (settingsExpanded && !compactMode) {
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        } else {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        }
        params.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        try { wm.updateViewLayout(panel, params) } catch (_: Exception) { }
    }

    private fun overlayPanelChanged() {
        val wm = overlayManager ?: return
        val panel = floatingPanel ?: return
        val params = overlayParams ?: return
        try { wm.updateViewLayout(panel, params) } catch (_: Exception) { }
    }

    private fun handleDragTouch(event: MotionEvent, onTap: () -> Unit): Boolean {
        val params = overlayParams ?: return true
        val wm = overlayManager ?: return true
        val panel = floatingPanel ?: return true
        val prefs = getSharedPreferences(TapLoopConfig.PREFS, MODE_PRIVATE)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragStartRawX = event.rawX
                dragStartRawY = event.rawY
                dragStartX = params.x
                dragStartY = params.y
                dragging = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - dragStartRawX
                val dy = event.rawY - dragStartRawY
                val slop = ViewConfiguration.get(this).scaledTouchSlop
                if (!dragging && (abs(dx) > slop || abs(dy) > slop)) dragging = true
                if (dragging) {
                    @Suppress("DEPRECATION")
                    val display = (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay
                    @Suppress("DEPRECATION")
                    val metrics = DisplayMetrics().also { display.getRealMetrics(it) }
                    val maxX = (metrics.widthPixels - panel.width).coerceAtLeast(0)
                    val maxY = (metrics.heightPixels - panel.height).coerceAtLeast(dp(24))
                    params.x = (dragStartX - dx.toInt()).coerceIn(0, maxX)
                    params.y = (dragStartY + dy.toInt()).coerceIn(dp(24), maxY)
                    try { wm.updateViewLayout(panel, params) } catch (_: Exception) { }
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) {
                    prefs.edit().putInt(TapLoopConfig.PANEL_X, params.x).putInt(TapLoopConfig.PANEL_Y, params.y).apply()
                } else {
                    onTap()
                }
                dragging = false
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                return true
            }
        }
        return true
    }

    private var dragStartRawX = 0f
    private var dragStartRawY = 0f
    private var dragStartX = 0
    private var dragStartY = 0
    private var dragging = false

    private fun enterCompactMode() {
        settingsExpanded = false
        compactMode = true
        settingsPanel?.visibility = View.GONE
        toolbar?.visibility = View.GONE
        compactControls?.visibility = View.VISIBLE
        floatingPanel?.orientation = LinearLayout.HORIZONTAL
        updateWindowFlags()
        overlayPanelChanged()
    }

    private fun exitCompactMode() {
        compactMode = false
        settingsExpanded = false
        floatingPanel?.orientation = LinearLayout.VERTICAL
        compactControls?.visibility = View.GONE
        toolbar?.visibility = View.VISIBLE
        settingsPanel?.visibility = View.GONE
        updateWindowFlags()
        overlayPanelChanged()
    }

    fun refreshFloatingControls() {
        startStopButton?.apply {
            text = if (running) "■" else "▶"
            background = rounded(if (running) Color.rgb(244, 63, 94) else Color.rgb(16, 185, 129), 16, Color.TRANSPARENT)
            contentDescription = if (running) "Остановить автокликер" else "Запустить автокликер"
        }
        settingsButton?.apply {
            background = rounded(if (settingsExpanded) Color.rgb(74, 96, 130) else Color.rgb(59, 130, 246), 16, Color.TRANSPARENT)
        }
        moveButton?.background = rounded(Color.rgb(100, 116, 139), 16, Color.TRANSPARENT)
        startStopButton?.let {
            it.contentDescription = if (running) "Остановить автокликер; нажатий: $clicksDone" else "Запустить автокликер"
        }
    }

    /** Lets the user select a physical screen coordinate using one tap. */
    fun beginCoordinateSelection() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Разреши отображение поверх других приложений", Toast.LENGTH_LONG).show()
            return
        }
        if (pickerView != null) return

        resumeAfterPicking = running
        if (running) {
            running = false
            handler.removeCallbacks(clickLoop)
            handler.removeCallbacks(stopDeadlineRunnable)
            refreshFloatingControls()
        }
        closeSettingsPanel()

        val chooser = FrameLayout(this).apply { setBackgroundColor(Color.argb(32, 7, 12, 25)) }
        val hint = TextView(this).apply {
            text = "КОСНИСЬ НУЖНОЙ ТОЧКИ\n\nКоординаты сохранятся автоматически"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(dp(18), dp(14), dp(18), dp(14))
            background = rounded(Color.rgb(18, 27, 45), 18, Color.rgb(54, 72, 100))
        }
        chooser.addView(hint, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP
        ).apply { setMargins(dp(18), dp(50), dp(18), 0) })
        chooser.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) savePickedPoint(event.rawX.toInt().coerceAtLeast(1), event.rawY.toInt().coerceAtLeast(1))
            true
        }

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        try {
            wm.addView(chooser, params)
            pickerManager = wm
            pickerView = chooser
        } catch (_: Exception) {
            pickerView = null
            pickerManager = null
            Toast.makeText(this, "Не удалось открыть выбор координат", Toast.LENGTH_LONG).show()
            if (resumeAfterPicking) {
                running = true
                handler.post(clickLoop)
            }
            refreshFloatingControls()
        }
    }

    private fun savePickedPoint(x: Int, y: Int) {
        requestedX = x
        requestedY = y
        tapMode = TapLoopConfig.MODE_PICK
        getSharedPreferences(TapLoopConfig.PREFS, MODE_PRIVATE).edit()
            .putInt(TapLoopConfig.X, x)
            .putInt(TapLoopConfig.Y, y)
            .putString(TapLoopConfig.MODE, TapLoopConfig.MODE_PICK)
            .putBoolean(TapLoopConfig.POINT_SELECTED, true)
            .apply()
        removeCoordinatePicker()
        refreshFloatingControls()
        Toast.makeText(this, "Точка сохранена: X=$x, Y=$y", Toast.LENGTH_SHORT).show()
        if (resumeAfterPicking) {
            startClicking(
                getSharedPreferences(TapLoopConfig.PREFS, MODE_PRIVATE).getLong(TapLoopConfig.INTERVAL, 500L),
                x, y, TapLoopConfig.MODE_PICK
            )
        }
        resumeAfterPicking = false
    }

    private fun removeCoordinatePicker() {
        val view = pickerView ?: return
        try { pickerManager?.removeView(view) } catch (_: Exception) { }
        pickerView = null
        pickerManager = null
    }

    private fun removeFloatingControls() {
        val panel = floatingPanel ?: return
        try { overlayManager?.removeView(panel) } catch (_: Exception) { }
        floatingPanel = null
        toolbar = null
        startStopButton = null
        settingsButton = null
        moveButton = null
        compactControls = null
        closePanelButton = null
        restorePanelButton = null
        settingsPanel = null
        intervalEditor = null
        intervalUnitSpinner = null
        stopConditionSpinner = null
        stopLimitEditor = null
        stopTimeUnitSpinner = null
        stopLimitSuffix = null
        overlayParams = null
        overlayManager = null
        settingsExpanded = false
        compactMode = false
    }

    private fun overlayButton(symbol: String, color: Int, description: String) = TextView(this).apply {
        text = symbol
        textSize = 22f
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        background = rounded(color, 16, Color.TRANSPARENT)
        contentDescription = description
        isClickable = true
        isFocusable = true
    }

    private fun overlayAction(title: String, backgroundColor: Int, foreground: Int, action: () -> Unit) = TextView(this).apply {
        text = title
        textSize = 12f
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(foreground)
        background = rounded(backgroundColor, 13, Color.rgb(54, 72, 100))
        isClickable = true
        isFocusable = true
        setOnClickListener { action() }
    }

    private fun numericField(value: String, decimal: Boolean): EditText = EditText(this).apply {
        setSingleLine(true)
        inputType = if (decimal) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL else InputType.TYPE_CLASS_NUMBER
        setText(value)
        textSize = 14f
        setTextColor(Color.WHITE)
        setHintTextColor(Color.rgb(151, 166, 188))
        setPadding(dp(10), dp(5), dp(8), dp(5))
        background = rounded(Color.rgb(12, 20, 35), 12, Color.rgb(54, 72, 100))
    }

    private fun unitSpinner(values: List<String>, selected: Int): Spinner = Spinner(this).apply {
        val adapter = ArrayAdapter(this@AutoClickAccessibilityService, android.R.layout.simple_spinner_item, values)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        this.adapter = adapter
        setSelection(selected.coerceIn(values.indices))
        background = rounded(Color.rgb(31, 45, 68), 12, Color.rgb(54, 72, 100))
    }

    private fun label(value: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun settingsWidth(): Int {
        @Suppress("DEPRECATION")
        val display = (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay
        @Suppress("DEPRECATION")
        val metrics = DisplayMetrics().also { display.getRealMetrics(it) }
        return minOf(dp(270), (metrics.widthPixels - dp(36)).coerceAtLeast(dp(210)))
    }

    private fun controlParams(bottom: Int = 0) = LinearLayout.LayoutParams(dp(48), dp(48)).apply { bottomMargin = dp(bottom) }
    private fun compactButtonParams(end: Int = 0) = LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginEnd = dp(end) }
    private fun itemParams(bottom: Int = 0, height: Int = ViewGroupParams.WRAP_CONTENT) = LinearLayout.LayoutParams(ViewGroupParams.MATCH_PARENT, if (height == ViewGroupParams.WRAP_CONTENT) height else dp(height)).apply { bottomMargin = dp(bottom) }
    private fun unitMultiplier(index: Int): Long = when (index) { 1 -> 1_000L; 2 -> 60_000L; else -> 1L }

    private fun formatAmount(value: Double): String = String.format(Locale.US, "%.6f", value).trimEnd('0').trimEnd('.').ifEmpty { "0" }

    private fun rounded(color: Int, radiusDp: Int, stroke: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() { stopClicking() }

    override fun onDestroy() {
        stopClicking()
        removeCoordinatePicker()
        removeFloatingControls()
        if (activeService === this) activeService = null
        super.onDestroy()
    }

    private object ViewGroupParams {
        const val MATCH_PARENT = -1
        const val WRAP_CONTENT = -2
    }
}
