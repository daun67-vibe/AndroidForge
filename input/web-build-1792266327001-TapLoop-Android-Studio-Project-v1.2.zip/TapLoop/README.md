# TapLoop 1.2

A native Kotlin Android auto-tapper for Android 8.0+.

## Changes in 1.2

- Insets-aware layout: the main UI keeps clear of status/navigation bars, camera cutouts and side insets.
- Redesigned floating vertical panel with Start/Stop, Settings, and Move/Compact controls.
- Long-press/drag the Move button to reposition the panel. A short tap opens a compact two-button mode (close/restore); long-press and drag Restore to move while compact.
- Floating settings for interval (ms/sec/min), stop after elapsed time, stop after N taps, or continue until Stop.
- Minimum click interval is 20 ms.
- Coordinate selection remains available from the floating settings panel.
- Stable application ID `com.example.taploop`, versionCode 3 / versionName 1.2.

## Important: stable APK updates

Android requires an APK update to use the same signing certificate as the installed version. AndroidForge's usual `debug` build uses a debug key that may change between cloud runs, so version-only changes are not enough.

This source ZIP deliberately contains **no private signing key**. For repeatable updates, configure the AndroidForge workflow to sign the generated unsigned APK in a separate post-build step, using GitHub Actions Secrets. See `TAPLOOP_SIGNING_SETUP.txt` (provided alongside this source archive), add the workflow snippet before the workflow's `Collect APKs` step, and create the two repository secrets named there.

Keep the keystore and its password private. Reuse the same key for all future TapLoop versions. Increase `versionCode` and `versionName` for every update. The first switch from an older APK signed with a different certificate can require one final uninstall/reinstall; later builds signed with this stable key should update in place and normally retain the app's permissions.

## Permissions

TapLoop requires the Android Accessibility Service to dispatch taps, plus the Android "Display over other apps" permission for its floating controls. Coordinate picking uses a temporary full-screen overlay and saves the selected screen coordinates.
